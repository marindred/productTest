package com.example.demo.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class InvalidFieldsException extends RuntimeException{

    private final String errorCode;

    public InvalidFieldsException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
}