package com.example.demo.service;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.exception.InvalidFieldsException;
import com.example.demo.exception.MissingRequiredFieldsException;
import com.example.demo.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
    private ProductRepo productRepo;

    public ProductServiceImpl(ProductRepo productRepository) {
        this.productRepo = productRepository;
    }

    @Override
    public Product createProduct(Product product) {
		if(product.getName() == null)
		{
			throw new MissingRequiredFieldsException("Product name is empty.", "PRODUCT_NAME_NULL");
		} else if (product.getPrice() == null)
		{
			throw new MissingRequiredFieldsException("Product price is empty.", "PRODUCT_PRICE_NULL");
		} else if (product.getCategory() == null)
		{
			throw new MissingRequiredFieldsException("Product category is empty.", "PRODUCT_CATEGORY_NULL");
		}
		
		if(product.getName().length() > 100)
		{
			throw new InvalidFieldsException("Product name exceeded max length of 100 characters.", "PRODUCT_NAME_TOO_LONG");
		} else if (product.getDescription() != null && product.getDescription().length() > 500)
		{
			throw new InvalidFieldsException("Product description exceeded max length of 500 characters.", "PRODUCT_DESCRIPTION_TOO_LONG");
		} else if (product.getPrice() < 0.001)
		{
			throw new InvalidFieldsException("Product price must be positive.", "PRODUCT_PRICE_NOT_POSITIVE");
		} else if (product.getCategory().length() > 50)
		{
			throw new InvalidFieldsException("Product category exceeded max length of 50 characters.", "PRODUCT_CATEGORY_TOO_LONG");
		} else if (!product.getImageUrl().isEmpty() &&!isValidUrl(product.getImageUrl()))
		{
			throw new InvalidFieldsException("Invalid Image Url", "INVALID_IMAGE_URL");
		}
        return productRepo.save(product);
    }
    public boolean isValidUrl(String url)
    {
        try {
            new URL(url).toURI();
            return true;
        } catch (MalformedURLException e) {
            return false;
        } catch (URISyntaxException e) {
            return false;
        }
    }
    @Override
    public Product getProductById(Long pid) {
        Optional<Product> optionalProduct = productRepo.findById(pid);
        return optionalProduct.orElse(null);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }
}
