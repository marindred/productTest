package com.example.demo.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MissingRequiredFieldsException extends RuntimeException{

    private final String errorCode;

    public MissingRequiredFieldsException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
}