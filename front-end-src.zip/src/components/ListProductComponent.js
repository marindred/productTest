import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ProductService from "../ProductService";

const ListProductComponent = () => {
  const navigate = useNavigate();
  const [products, setProducts] = React.useState([]);

  useEffect(() => {
    ProductService.getProducts().then((res) => {
      setProducts(res.data);
    });
  }, []);

  const addProduct = () => {
    navigate("/add-product/_add");
  };

  return (
    <div>
      <h2 className="text-center">Products List</h2>
      <div className="row">
        <button className="btn btn-primary" onClick={addProduct}>
          Add Product
        </button>
      </div>
      <br />
      <div className="row">
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Product Description</th>
              <th>Product Price</th>
              <th>Product Category</th>
              <th>Image URL</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.pid}>
                <td>{product.name}</td>
                <td>{product.description}</td>
                <td>{product.price}</td>
                <td>{product.category}</td>
                <td>{product.imageUrl}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ListProductComponent;
