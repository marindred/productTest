import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ListProductComponent from './components/ListProductComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateProductComponent from './components/CreateProductComponent';
function App() {
  return (
    <div>
      <Router>
        <HeaderComponent />
        <div className="container">
          <Routes>
            <Route path="/" element={<ListProductComponent />} />
            <Route path="/products" element={<ListProductComponent />} />
            <Route path="/add-product/:id" element={<CreateProductComponent />} />
          </Routes>
        </div>
        <FooterComponent />
      </Router>
    </div>
  );
}
export default App;
